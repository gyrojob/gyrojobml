<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    die;
}


	global $wpdb, $table_prefix;

?>